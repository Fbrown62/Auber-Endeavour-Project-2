# Auber | 3³ Studios

## Licenses
## Contributing
- All code should be linted using the checkstyle linter and the `google_checks.xml` configuration file that comes with it.
