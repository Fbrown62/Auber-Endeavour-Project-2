<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.2" name="tileset" tilewidth="16" tileheight="16" tilecount="144" columns="12">
 <image source="tileset.png" width="192" height="192"/>
 <tile id="37">
  <animation>
   <frame tileid="37" duration="100"/>
   <frame tileid="38" duration="100"/>
  </animation>
 </tile>
 <tile id="39">
  <animation>
   <frame tileid="39" duration="100"/>
   <frame tileid="40" duration="100"/>
  </animation>
 </tile>
 <tile id="49">
  <animation>
   <frame tileid="49" duration="400"/>
   <frame tileid="50" duration="400"/>
  </animation>
 </tile>
 <tile id="51">
  <animation>
   <frame tileid="51" duration="400"/>
   <frame tileid="52" duration="400"/>
  </animation>
 </tile>
 <tile id="61">
  <animation>
   <frame tileid="61" duration="100"/>
   <frame tileid="62" duration="100"/>
  </animation>
 </tile>
 <tile id="63">
  <animation>
   <frame tileid="63" duration="100"/>
   <frame tileid="64" duration="100"/>
  </animation>
 </tile>
</tileset>
